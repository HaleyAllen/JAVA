package com.codingdojo.zookeeper;

public class GorillaTest {

	public static void main(String[] args) {
		
		Gorilla george = new Gorilla();
		george.displayEnergy();
		System.out.println("Hello World");

	}

}
