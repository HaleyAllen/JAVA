package com.codingdojo.dikichiroutes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DikichiroutesApplicationTests {

	@Test
	void contextLoads() {
	}

}
