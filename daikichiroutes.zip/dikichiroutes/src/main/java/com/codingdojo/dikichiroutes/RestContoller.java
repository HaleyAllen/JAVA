package com.codingdojo.dikichiroutes;

public @interface RestContoller {

}
